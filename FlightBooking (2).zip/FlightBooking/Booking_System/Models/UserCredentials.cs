﻿using System;
using System.Collections.Generic;

namespace Booking_System.Models
{
    public partial class UserCredentials
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string ContactNo { get; set; }
        public string Gender { get; set; }
        public string Age { get; set; }
        public string Address { get; set; }
    }
}
