﻿using System;
using System.Collections.Generic;

namespace Booking_System.Models
{
    public partial class Flights
    {
        public int Id { get; set; }
        public string FlightId { get; set; }
        public string Flightname { get; set; }
        public string Flightlogo { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string ScheduledDays { get; set; }
        public string Bcseats { get; set; }
        public string Ncbseats { get; set; }
        public string Price { get; set; }
        public int? MealType { get; set; }
        public int? RoundTrip { get; set; }
    }
}
