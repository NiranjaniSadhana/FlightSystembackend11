﻿using System;
using System.Collections.Generic;

namespace AdminStories.Models
{
    public partial class AirlineaddBlock
    {
        public int Id { get; set; }
        public string AirlineId { get; set; }
        public string Airlinename { get; set; }
    }
}
