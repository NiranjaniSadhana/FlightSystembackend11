﻿using AdminStories.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminStories.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class BlockFlightController : ControllerBase
    {
        
        [HttpGet]
        [Route("AllFlightDetails")]
        public List<AirlineaddBlock> AllFlightDetails()
        {
            using (var db = new AdminServicesContext())
            {
                return db.AirlineaddBlock.ToList();
            }
        }


        
        [HttpPost]
        [Route("AddFlight")]
        public int AddFlight([FromBody] AirlineaddBlock data)
        {
            if (string.IsNullOrEmpty(data.AirlineId) || string.IsNullOrEmpty(data.Airlinename))
                return 0;
            else
            {
                using (var db = new AdminServicesContext())
                {
                    db.AirlineaddBlock.Add(data);
                    db.SaveChanges();
                    return 1;
                }
               
                
            }
        }

        
        [HttpDelete]
        [Route("BlockFlight")]
        public int BlockFlight(string Airline_ID)
        {
            using (var db = new AdminServicesContext())
            {
                var airline = db.AirlineaddBlock.SingleOrDefault(x => x.AirlineId == Airline_ID);
                db.AirlineaddBlock.Remove(airline);
                return db.SaveChanges();
            }

        }
    }
}
